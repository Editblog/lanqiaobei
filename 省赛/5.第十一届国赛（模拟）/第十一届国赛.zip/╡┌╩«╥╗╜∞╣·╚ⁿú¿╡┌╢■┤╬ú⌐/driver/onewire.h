#ifndef __ONEWIRE_H
#define __ONEWIRE_H

float rd_temperature_f(void);

#endif
